"""Unified pipeline for auto-detecting and processing all returns into CSVs."""

import os
import glob
import re
import pandas as pd
import pdfplumber
from typing import Callable

from .utils import clean_cell, to_float
from .gstr1.parser import parse_gstr1
from .gstr1.checks import run_sanity_checks_gstr1
from .gstr3b.parser import parse_complete_gstr3b
from .gstr3b.checks import run_sanity_checks_gstr3b
from .compliance_parsers import parse_esic, parse_pf, parse_ptrc, parse_tds

def detect_return_type(first_page_text: str) -> str:
    text_upper = first_page_text.upper()
    if "GSTR-3B" in text_upper or "GSTR3B" in text_upper:
        return "GSTR3B"
    elif "GSTR-1" in text_upper or "GSTR1" in text_upper:
        return "GSTR1"
    elif "CHALLAN PERIOD:" in text_upper and "CHALLAN NUMBER" in text_upper:
        return "ESIC"
    elif "ESTABLISHMENT CODE" in text_upper and "CHALLAN" in text_upper:
        return "PF"
    elif "PTRC" in text_upper or ("TYPE OF PAYMENT" in text_upper and "AMOUNT OF TAX" in text_upper):
        return "PTRC"
    elif "TAX ID/TAN" in text_upper or "DATE OF DEPOSIT" in text_upper or "FINANCIAL YEAR" in text_upper:
        if "NATURE OF PAYMENT" in text_upper or "CHALLAN NO" in text_upper or "AMOUNT (IN RS.)" in text_upper:
            return "TDS"
            
    # Extra fallback signatures
    if "EMPLOYEE'S STATE INSURANCE" in text_upper:
        return "ESIC"
    if "EMPLOYEES' PROVIDENT FUND" in text_upper or "AC01" in text_upper:
        return "PF"
    if "PROFESSION TAX" in text_upper:
        return "PTRC"
    if "TDS" in text_upper or "TAX DEDUCTED AT SOURCE" in text_upper:
        return "TDS"
    return "Unknown"

def run_unified_pipeline(input_folder: str, output_dir: str, progress_cb: Callable | None = None) -> list[dict]:
    os.makedirs(output_dir, exist_ok=True)
    pdf_files = sorted(glob.glob(os.path.join(input_folder, "*.pdf")))
    if not pdf_files:
        raise FileNotFoundError("No PDF files found in the input folder.")
        
    if progress_cb:
        progress_cb("1", f"Found {len(pdf_files)} PDF(s). Analyzing...")
        
    records = []
    errors = []
    
    # Raw detail lists for return-specific CSVs
    raw_details = {
        "GSTR1": [],
        "GSTR3B": [],
        "ESIC": [],
        "PF": [],
        "PTRC": [],
        "TDS": []
    }
    
    for idx, fpath in enumerate(pdf_files, 1):
        fname = os.path.basename(fpath)
        if progress_cb:
            progress_cb("2", f"Parsing {idx}/{len(pdf_files)}: {fname}")
            
        try:
            with pdfplumber.open(fpath) as pdf:
                if not pdf.pages:
                    raise ValueError("PDF has no pages")
                first_text = pdf.pages[0].extract_text() or ""
                return_type = detect_return_type(first_text)
                
                if return_type == "Unknown":
                    # Try combining tables text in case first page extract_text failed
                    from .compliance_parsers import get_pdf_combined_text
                    comb_text = get_pdf_combined_text(pdf)
                    return_type = detect_return_type(comb_text)
                
                if return_type == "GSTR1":
                    res = parse_gstr1(fpath, errors)
                    if res:
                        meta = res["Metadata"]
                        sec_totals = res["Section_Totals"]
                        
                        # Sanity checks
                        chk_errs = run_sanity_checks_gstr1(sec_totals, meta, [])
                        flags = "; ".join([e["Check"] for e in chk_errs])
                        status = "Error" if any(e.get("Status") == "FAIL" for e in chk_errs) else ("Review" if flags else "OK")
                        
                        # Find TOTAL_LIABILITY tax amount as PrimaryAmount
                        tot_row = sec_totals[sec_totals["Section_Code"] == "TOTAL_LIABILITY"]
                        if not tot_row.empty:
                            r = tot_row.iloc[0]
                            primary_amt = to_float(r.get("IGST", 0)) + to_float(r.get("CGST", 0)) + to_float(r.get("SGST", 0)) + to_float(r.get("Cess", 0))
                        else:
                            primary_amt = 0.0
                            
                        pd_date = None
                        try:
                            # Convert Period_Year to start of month
                            pd_date = pd.to_datetime(meta["Period_Year"], format="%b-%y")
                        except Exception:
                            try:
                                pd_date = pd.to_datetime(meta["Period_Year"], format="%b %Y")
                            except Exception:
                                pass
                                
                        month_idx = 0
                        if pd_date is not None:
                            cal_m = pd_date.month
                            month_idx = cal_m - 3 if cal_m >= 4 else cal_m + 9
                            
                        records.append({
                            "ReturnType": "GSTR1",
                            "EntityID": meta.get("GSTIN", "Unknown"),
                            "EntityName": meta.get("Legal_Name", "Unknown"),
                            "FY": meta.get("FY", "Unknown"),
                            "PeriodDate": pd_date.strftime("%Y-%m-%d") if pd_date is not None else None,
                            "MonthName": pd_date.strftime("%B") if pd_date is not None else "Unknown",
                            "MonthIndex": month_idx,
                            "Status": status,
                            "Flags": flags,
                            "PrimaryAmount": primary_amt,
                            "SourceFile": fname
                        })
                        
                        # Save details (meta + section totals)
                        for _, row in sec_totals.iterrows():
                            detail_row = {"SourceFile": fname}
                            detail_row.update(meta)
                            detail_row.update(row.to_dict())
                            raw_details["GSTR1"].append(detail_row)
                            
                elif return_type == "GSTR3B":
                    res = parse_complete_gstr3b(fpath, errors)
                    if res:
                        meta = res["Metadata"]
                        
                        # Run checks
                        file_tables = {
                            k: v for k, v in res.items() 
                            if k != "Metadata" and isinstance(v, pd.DataFrame) and not v.empty
                        }
                        gstin = meta.get("GSTIN", "Unknown")
                        period = meta.get("Period_Year", "Unknown")
                        
                        audited_tables, chk_errs = run_sanity_checks_gstr3b(file_tables, gstin, period)
                        flags = "; ".join([e["Check"] for e in chk_errs])
                        status = "Error" if any(e.get("Audit_Status") == "FAIL" for e in chk_errs) else ("Review" if flags else "OK")
                        
                        # Compute PrimaryAmount
                        t61 = file_tables.get("Table_6_1")
                        primary_amt = 0.0
                        if t61 is not None and not t61.empty:
                            # Sum Net_Tax_Payable or Tax_paid_cash from table 6.1
                            for col in ["Net_Tax_Payable", "Tax_Payable"]:
                                if col in t61.columns:
                                    primary_amt = float(t61[col].sum())
                                    break
                                    
                        pd_date = None
                        try:
                            pd_date = pd.to_datetime(meta["Period_Year"], format="%b-%y")
                        except Exception:
                            try:
                                pd_date = pd.to_datetime(meta["Period_Year"], format="%b %Y")
                            except Exception:
                                pass
                                
                        month_idx = 0
                        if pd_date is not None:
                            cal_m = pd_date.month
                            month_idx = cal_m - 3 if cal_m >= 4 else cal_m + 9
                            
                        records.append({
                            "ReturnType": "GSTR3B",
                            "EntityID": gstin,
                            "EntityName": meta.get("Legal_Name", "Unknown"),
                            "FY": meta.get("Year", "Unknown"),
                            "PeriodDate": pd_date.strftime("%Y-%m-%d") if pd_date is not None else None,
                            "MonthName": pd_date.strftime("%B") if pd_date is not None else "Unknown",
                            "MonthIndex": month_idx,
                            "Status": status,
                            "Flags": flags,
                            "PrimaryAmount": primary_amt,
                            "SourceFile": fname
                        })
                        
                        # Flat representation for raw_details["GSTR3B"]
                        # Just summarize values for outward/inward tax
                        flat_row = {"SourceFile": fname}
                        flat_row.update(meta)
                        # Add outward tax summary if available
                        t31 = file_tables.get("Table_3_1")
                        if t31 is not None and not t31.empty:
                            flat_row["Output_IGST"] = to_float(t31.get("Integrated tax", pd.Series([0])).sum())
                            flat_row["Output_CGST"] = to_float(t31.get("Central tax", pd.Series([0])).sum())
                            flat_row["Output_SGST"] = to_float(t31.get("State/UT tax", pd.Series([0])).sum())
                        t4 = file_tables.get("Table_4_ITC")
                        if t4 is not None and not t4.empty:
                            flat_row["Net_ITC_IGST"] = to_float(t4.get("Integrated tax", pd.Series([0])).sum())
                            flat_row["Net_ITC_CGST"] = to_float(t4.get("Central tax", pd.Series([0])).sum())
                            flat_row["Net_ITC_SGST"] = to_float(t4.get("State/UT tax", pd.Series([0])).sum())
                        raw_details["GSTR3B"].append(flat_row)
                        
                elif return_type == "ESIC":
                    res = parse_esic(pdf, fname)
                    res["SourceFile"] = fname
                    raw_details["ESIC"].append(res)
                    
                elif return_type == "PF":
                    res = parse_pf(pdf, fname)
                    res["SourceFile"] = fname
                    
                    # Sanity checks
                    flags_list = []
                    if res["EntityID"] == "PARSE ERROR":
                        flags_list.append("PARSE ERR")
                    if res["PeriodDate"] is None:
                        flags_list.append("PERIOD?")
                    if res.get("Employer_EPS_AC10", 0) > res.get("Employer_EPF_AC01", 0) + 1:
                        flags_list.append("EPS>EPF?")
                    if abs(res.get("Employee_EPF_AC01", 0) - (res.get("Employer_EPF_AC01", 0) + res.get("Employer_EPS_AC10", 0))) > 1:
                        flags_list.append("EE<>ER(EPF+EPS)")
                    if not res.get("PF_Admin_AC02"):
                        flags_list.append("NO ADMIN")
                        
                    flags = "; ".join(flags_list)
                    status = "Error" if "PARSE ERR" in flags_list else ("Review" if flags else "OK")
                    primary_amt = res["Employer_EPF_AC01"] + res["Employer_EPS_AC10"] + res["Employer_EDLI_AC21"] + res["PF_Admin_AC02"] + res["EDLI_Admin_AC22"] + res["Employee_EPF_AC01"]
                    
                    pd_date = res["PeriodDate"]
                    month_idx = 0
                    if pd_date is not None:
                        cal_m = pd_date.month
                        month_idx = cal_m - 3 if cal_m >= 4 else cal_m + 9
                        
                    records.append({
                        "ReturnType": "PF",
                        "EntityID": res["EntityID"],
                        "EntityName": res["EntityName"],
                        "FY": res["FY"],
                        "PeriodDate": pd_date.strftime("%Y-%m-%d") if pd_date is not None else None,
                        "MonthName": pd_date.strftime("%B") if pd_date is not None else "Unknown",
                        "MonthIndex": month_idx,
                        "Status": status,
                        "Flags": flags,
                        "PrimaryAmount": primary_amt,
                        "SourceFile": fname
                    })
                    
                    raw_details["PF"].append(res)
                    
                elif return_type == "PTRC":
                    res = parse_ptrc(pdf, fname)
                    res["SourceFile"] = fname
                    
                    flags_list = []
                    if res["EntityName"] == "ERROR" or res["Type of Return"] == "ERROR":
                        flags_list.append("PARSE ERR")
                    if res["PeriodDate"] is None:
                        flags_list.append("PERIOD?")
                    if res["PT Paid"] <= 0:
                        flags_list.append("AMT?")
                    if "PTRC" not in res["Type of Return"].upper():
                        flags_list.append("TYPE?")
                    if not res["EntityID"] or res["EntityID"] == "Unknown":
                        flags_list.append("TAN?")
                        
                    flags = "; ".join(flags_list)
                    status = "Error" if "PARSE ERR" in flags_list else ("Review" if flags else "OK")
                    
                    pd_date = res["PeriodDate"]
                    month_idx = 0
                    if pd_date is not None:
                        cal_m = pd_date.month
                        month_idx = cal_m - 3 if cal_m >= 4 else cal_m + 9
                        
                    records.append({
                        "ReturnType": "PTRC",
                        "EntityID": res["EntityID"],
                        "EntityName": res["EntityName"],
                        "FY": res["FY"],
                        "PeriodDate": pd_date.strftime("%Y-%m-%d") if pd_date is not None else None,
                        "MonthName": pd_date.strftime("%B") if pd_date is not None else "Unknown",
                        "MonthIndex": month_idx,
                        "Status": status,
                        "Flags": flags,
                        "PrimaryAmount": res["PT Paid"],
                        "SourceFile": fname
                    })
                    
                    raw_details["PTRC"].append(res)
                    
                elif return_type == "TDS":
                    res = parse_tds(pdf, fname)
                    res["SourceFile"] = fname
                    
                    flags_list = []
                    if res["EntityID"] == "ERROR":
                        flags_list.append("PARSE ERR")
                    if res["PeriodDate"] is None:
                        flags_list.append("MONTH?")
                    if abs(res["Crosscheck Diff"]) > 1.0:
                        flags_list.append("CROSSCHECK")
                    if not res["Section"] or res["Section"] == "Unknown":
                        flags_list.append("SECTION?")
                    if res["Total Amount Paid"] <= 0:
                        flags_list.append("AMT?")
                        
                    flags = "; ".join(flags_list)
                    status = "Error" if "PARSE ERR" in flags_list else ("Review" if flags else "OK")
                    
                    pd_date = res["PeriodDate"]
                    month_idx = 0
                    if pd_date is not None:
                        cal_m = pd_date.month
                        month_idx = cal_m - 3 if cal_m >= 4 else cal_m + 9
                        
                    records.append({
                        "ReturnType": "TDS",
                        "EntityID": res["EntityID"],
                        "EntityName": res["EntityName"],
                        "FY": res["FY"],
                        "PeriodDate": pd_date.strftime("%Y-%m-%d") if pd_date is not None else None,
                        "MonthName": pd_date.strftime("%B") if pd_date is not None else "Unknown",
                        "MonthIndex": month_idx,
                        "Status": status,
                        "Flags": flags,
                        "PrimaryAmount": res["Total Amount Paid"],
                        "SourceFile": fname
                    })
                    
                    raw_details["TDS"].append(res)
                else:
                    errors.append({
                        "File": fname,
                        "Error_Type": "UnknownType",
                        "Message": "Could not identify return type.",
                        "Action": "Skipped."
                    })
                    
        except Exception as exc:
            errors.append({
                "File": fname,
                "Error_Type": type(exc).__name__,
                "Message": str(exc),
                "Action": "Could not read this file. Damaged or password-protected."
            })
            
    # Post-process ESIC unpivoting / ranking / common contract construction
    if raw_details["ESIC"]:
        df_esic = pd.DataFrame(raw_details["ESIC"])
        # Group by FY and Month, sort each group descending by Amount
        df_esic = df_esic.sort_values(by=["FY", "Month", "Amount"], ascending=[True, True, False])
        df_esic["rank"] = df_esic.groupby(["FY", "Month"]).cumcount()
        df_esic["Party"] = df_esic["rank"].map(lambda r: "Employer" if r == 0 else ("Employee" if r == 1 else "Other"))
        df_esic = df_esic.drop(columns=["rank"])
        
        # Build common contract records for ESIC
        for _, row in df_esic.iterrows():
            flags_list = []
            if row["ChallanNumber"] == "ERROR":
                flags_list.append("PARSE ERR")
            if pd.isna(row["PeriodDate"]):
                flags_list.append("PERIOD?")
            if row["Party"] == "Other":
                flags_list.append("EXTRA CHALLAN")
            if pd.isna(row["Amount"]) or row["Amount"] <= 0:
                flags_list.append("AMT?")
                
            flags = "; ".join(flags_list)
            status = "Error" if "PARSE ERR" in flags_list else ("Review" if flags else "OK")
            
            pd_date = row["PeriodDate"]
            month_idx = 0
            if pd_date is not None and not pd.isna(pd_date):
                cal_m = pd_date.month
                month_idx = cal_m - 3 if cal_m >= 4 else cal_m + 9
                
            records.append({
                "ReturnType": "ESIC",
                "EntityID": "",
                "EntityName": "",
                "FY": row["FY"],
                "PeriodDate": pd_date.strftime("%Y-%m-%d") if pd_date is not None and not pd.isna(pd_date) else None,
                "MonthName": pd_date.strftime("%B") if pd_date is not None and not pd.isna(pd_date) else "Unknown",
                "MonthIndex": month_idx,
                "Status": status,
                "Flags": flags,
                "PrimaryAmount": row["Amount"],
                "SourceFile": row["SourceFile"]
            })
            
        # Re-save ESIC detail list
        raw_details["ESIC"] = df_esic.to_dict("records")
        
    # Write CSVs
    output_files = []
    
    # 1. Consolidated Ledger
    if records:
        df_all = pd.DataFrame(records)
        # Format PeriodDate
        df_all["PeriodDate"] = pd.to_datetime(df_all["PeriodDate"])
        df_all = df_all.sort_values(by=["ReturnType", "FY", "MonthIndex", "EntityID"])
        # Format date as YYYY-MM-DD
        df_all["PeriodDate"] = df_all["PeriodDate"].dt.strftime("%Y-%m-%d")
        
        path_all = os.path.join(output_dir, "All_Returns_Consolidated.csv")
        df_all.to_csv(path_all, index=False)
        output_files.append({
            "label": "Consolidated Ledger",
            "desc": "All parsed returns combined under a unified contract schema.",
            "filename": "All_Returns_Consolidated.csv",
            "path": path_all
        })
        
        # 2. Dashboard Summary
        df_dash = df_all.groupby(["ReturnType", "FY"]).agg(
            Records=("Status", "count"),
            OK=("Status", lambda s: (s == "OK").sum()),
            Review=("Status", lambda s: (s == "Review").sum()),
            Errors=("Status", lambda s: (s == "Error").sum()),
            Periods=("PeriodDate", "nunique"),
            TotalPrimaryAmount=("PrimaryAmount", "sum")
        ).reset_index()
        
        df_dash["FlagRate"] = ((df_dash["Review"] + df_dash["Errors"]) / df_dash["Records"]).round(3)
        df_dash = df_dash.sort_values(by=["ReturnType", "FY"])
        
        path_dash = os.path.join(output_dir, "Dashboard_Summary.csv")
        df_dash.to_csv(path_dash, index=False)
        output_files.append({
            "label": "Dashboard Summary",
            "desc": "High-level filing counts, pass rates, and amount sums grouped by return and FY.",
            "filename": "Dashboard_Summary.csv",
            "path": path_dash
        })
        
    # 3. Write Detailed CSVs for whatever parsed categories we have
    for rtype, rlist in raw_details.items():
        if rlist:
            df_det = pd.DataFrame(rlist)
            # Remove pd.Timestamp objects if any
            for col in df_det.columns:
                if pd.api.types.is_datetime64_any_dtype(df_det[col]):
                    df_det[col] = df_det[col].dt.strftime("%Y-%m-%d")
                    
            path_det = os.path.join(output_dir, f"{rtype}_Details.csv")
            df_det.to_csv(path_det, index=False)
            output_files.append({
                "label": f"{rtype} Details",
                "desc": f"Detailed raw and parsed fields specific to {rtype} returns.",
                "filename": f"{rtype}_Details.csv",
                "path": path_det
            })
            
    # 4. Error logs CSV if there were failures
    if errors:
        df_err = pd.DataFrame(errors)
        path_err = os.path.join(output_dir, "Parsing_Errors.csv")
        df_err.to_csv(path_err, index=False)
        output_files.append({
            "label": "Parsing Errors Log",
            "desc": "List of files that failed parsing or categorization with error types and actions.",
            "filename": "Parsing_Errors.csv",
            "path": path_err
        })
        
    if progress_cb:
        progress_cb("3", "Pipeline complete. CSV ledgers generated.")
        
    return output_files
