"""Parsers for ESIC, PF, PTRC, and TDS returns."""

import os
import re
import pandas as pd
from .utils import clean_cell, to_float

def get_pdf_combined_text(pdf) -> str:
    # Concatenate all tables' cell text first as a layout-preserved string
    cells = []
    for page in pdf.pages:
        for table in page.extract_tables() or []:
            for row in table:
                for cell in row:
                    val = clean_cell(cell)
                    if val:
                        cells.append(val)
    text_from_tables = " ".join(cells)
    if text_from_tables.strip():
        return text_from_tables
    # Fallback to direct text extraction if no tables found
    return " ".join([page.extract_text() or "" for page in pdf.pages])

def find_between(text: str, start_lbl: str, end_lbl: str, max_chars: int = 500) -> str:
    text_upper = text.upper()
    start_lbl_upper = start_lbl.upper()
    end_lbl_upper = end_lbl.upper()
    
    idx_start = text_upper.find(start_lbl_upper)
    if idx_start == -1:
        return ""
    
    start_pos = idx_start + len(start_lbl)
    idx_end = text_upper.find(end_lbl_upper, start_pos)
    if idx_end == -1 or (idx_end - start_pos) > max_chars:
        return ""
        
    return text[start_pos:idx_end].strip()

def find_after(text: str, lbl: str, width: int = 30) -> str:
    text_upper = text.upper()
    lbl_upper = lbl.upper()
    idx = text_upper.find(lbl_upper)
    if idx == -1:
        return ""
    start_pos = idx + len(lbl)
    return text[start_pos:start_pos + width].strip()

def parse_ptrc(pdf, fname) -> dict:
    all_text = get_pdf_combined_text(pdf)
    
    # Type of Return
    raw_type = find_between(all_text, "Type of Payment", "Office Name")
    if "Maharashtra Profession Tax PTRC" in raw_type:
        type_of_return = "Maharashtra Profession Tax PTRC"
    else:
        type_of_return = raw_type if raw_type else "Unknown"
        
    # TAN
    tan_raw = ""
    for lbl in ("TAX ID/TAN (If Any)", "TAX ID / TAN (If Any)", "TAN (If Any)"):
        val = find_after(all_text, lbl, 30)
        if val:
            tan_raw = val
            break
    tan_val = tan_raw.split(" ")[0] if tan_raw else ""
    if tan_val in ("PAN", "Type", "Full"):
        tan_val = ""
        
    # Company Name
    name_part1 = find_between(all_text, "Full Name", "Location")
    name_part2 = find_between(all_text, "Remarks (If Any)", "Amount In", max_chars=150)
    company_name = f"{name_part1} {name_part2}".strip()
    if not company_name:
        company_name = "Unknown"
        
    # Date of filing
    filing_date = find_after(all_text, "Date ", 10).split(" ")[0]
    
    # Year
    year_raw = find_after(all_text, "Year", 15)
    year_val = year_raw.split(" ")[0] if year_raw else "Unknown"
    
    # Month & Dates
    from_date_raw = find_after(all_text, "From ", 10).split(" ")[0]
    from_date = None
    try:
        from_date = pd.to_datetime(from_date_raw, format="%d/%m/%Y")
    except Exception:
        pass
        
    if from_date is not None:
        month_val = from_date.strftime("%B %Y")
        return_month_date = from_date - pd.DateOffset(months=1)
        ptrc_return_month = return_month_date.strftime("%b %Y")
        period_date = return_month_date.replace(day=1)
    else:
        month_val = "Unknown"
        ptrc_return_month = "Unknown"
        period_date = None
        
    # PT Paid
    amt_raw = find_after(all_text, "AMOUNT OF TAX", 20)
    pt_paid = to_float(amt_raw.split(" ")[0]) if amt_raw else 0.0
    
    # Challan No
    ref_raw = find_after(all_text, "Ref. No.", 30)
    challan_no = ref_raw.split(" ")[0] if ref_raw else "Unknown"
    
    return {
        "ReturnType": "PTRC",
        "EntityID": tan_val,
        "EntityName": company_name,
        "Type of Return": type_of_return,
        "PTRC return for the month": ptrc_return_month,
        "Date of filing": filing_date,
        "Year": year_val,
        "Month": month_val,
        "PT Paid": pt_paid,
        "Challan No.": challan_no,
        "PeriodDate": period_date
    }

def parse_tds(pdf, fname) -> dict:
    cells = []
    for page in pdf.pages:
        for table in page.extract_tables() or []:
            for row in table:
                for cell in row:
                    cells.append(str(cell or "").strip())
                    
    clean_cells_orig = [c.replace(":", "").strip() for c in cells if c.replace(":", "").strip()]
    clean_cells_upper = [c.upper() for c in clean_cells_orig]
    
    def find_idx(lbl: str) -> int:
        try:
            return clean_cells_upper.index(lbl.upper())
        except ValueError:
            return -1
            
    def find_val(lbl: str) -> str:
        idx = find_idx(lbl)
        if idx >= 0 and idx + 1 < len(clean_cells_orig):
            return clean_cells_orig[idx + 1]
        return ""
        
    def find_val_between(lbl1: str, lbl2: str) -> str:
        idx1 = find_idx(lbl1)
        idx2 = find_idx(lbl2)
        if idx1 >= 0 and idx2 > idx1:
            return " ".join(clean_cells_orig[idx1 + 1 : idx2])
        return find_val(lbl1)
        
    tan_val = find_val("TAN") or "Unknown"
    company_name_raw = find_val_between("NAME", "FINANCIAL YEAR")
    idx_ass = company_name_raw.upper().find("ASSESSMENT YEAR")
    company_name = company_name_raw[:idx_ass].strip() if idx_ass >= 0 else company_name_raw
    
    fy_val = find_val("FINANCIAL YEAR")
    nop_raw = find_val("NATURE OF PAYMENT")
    section_val = nop_raw.split(" ")[0] if nop_raw else "Unknown"
    
    major_head_raw = find_val("MAJOR HEAD")
    mh_upper = major_head_raw.upper()
    if "OTHER THAN COMPAN" in mh_upper or "0021" in mh_upper:
        major_head_val = "Other than Companies"
    elif "COMPAN" in mh_upper or "CORPORATION" in mh_upper or "0020" in mh_upper:
        major_head_val = "Corporation Tax"
    else:
        major_head_val = major_head_raw.split("(")[0].strip() if major_head_raw else "Unknown"
        
    challan_no_val = find_val("CHALLAN NO")
    p_date_str = find_val("DATE OF DEPOSIT")
    
    payment_date = None
    for fmt in ("%d-%b-%Y", "%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d"):
        try:
            payment_date = pd.to_datetime(p_date_str, format=fmt)
            break
        except Exception:
            pass
    if payment_date is None:
        try:
            payment_date = pd.to_datetime(p_date_str)
        except Exception:
            pass
            
    total_amount_paid = to_float(find_val("AMOUNT (IN RS.)"))
    tax = to_float(find_val("TAX"))
    surcharge = to_float(find_val("SURCHARGE"))
    cess = to_float(find_val("CESS"))
    interest = to_float(find_val("INTEREST"))
    penalty = to_float(find_val("PENALTY"))
    fee = to_float(find_val("FEE UNDER SECTION 234E"))
    
    crosscheck_diff = total_amount_paid - (tax + surcharge + cess + interest + penalty + fee)
    
    deduction_date = None
    if payment_date is not None:
        p_day = payment_date.day
        p_month = payment_date.month
        p_year = payment_date.year
        if p_month == 4:
            deduction_date = pd.Timestamp(year=p_year, month=3, day=1)
        elif p_day <= 7:
            deduction_date = payment_date - pd.DateOffset(months=1)
        elif interest > 0:
            deduction_date = payment_date - pd.DateOffset(months=1)
        else:
            deduction_date = payment_date
            
    if deduction_date is not None:
        tds_month = deduction_date.strftime("%B %Y")
        period_date = deduction_date.replace(day=1)
    else:
        tds_month = "Unknown"
        period_date = None
        
    return {
        "ReturnType": "TDS",
        "EntityID": tan_val,
        "EntityName": company_name,
        "FY": fy_val,
        "Month": tds_month,
        "Section": section_val,
        "Major Head": major_head_val,
        "Total Amount Paid": total_amount_paid,
        "Tax": tax,
        "Surcharge": surcharge,
        "Cess": cess,
        "Interest": interest,
        "Penalty": penalty,
        "Fee under section 234E": fee,
        "Crosscheck Diff": crosscheck_diff,
        "Challan No": challan_no_val,
        "Payment Date": payment_date,
        "PeriodDate": period_date
    }

def parse_pf(pdf, fname) -> dict:
    all_rows = []
    for page in pdf.pages:
        for table in page.extract_tables() or []:
            for row in table:
                all_rows.append([str(c or "").strip() for c in row])
                
    all_text = get_pdf_combined_text(pdf)
    
    def find_rows(lbl: str) -> list:
        lbl_upper = lbl.upper()
        return [r for r in all_rows if any(lbl_upper in str(c).upper() for c in r)]
        
    def get_nums(r: list, lbl: str) -> list:
        lbl_upper = lbl.upper()
        lbl_idx = -1
        for idx, c in enumerate(r):
            if lbl_upper in str(c).upper():
                lbl_idx = idx
                break
        after = r[lbl_idx + 1 :] if lbl_idx >= 0 else r
        nums = []
        for val in after:
            nums.append(to_float(val))
        return nums + [0.0] * 10
        
    def g_pf(lbl: str, n: int = 0) -> list:
        rows = find_rows(lbl)
        if len(rows) > n:
            return get_nums(rows[n], lbl)
        return [0.0] * 10
        
    # Est details
    est_substr = find_between(all_text, "Establishment Code & Name", "Address")
    if est_substr:
        parts = [p for p in est_substr.split(" ") if p.strip()]
        estab_code = parts[0] if parts else "Unknown"
        estab_name_raw = est_substr.replace(estab_code, "").strip()
        if "Dues for" in estab_name_raw:
            estab_name = estab_name_raw.split("Dues for")[0].strip()
        else:
            estab_name = estab_name_raw
    else:
        estab_code = "Unknown"
        estab_name = "Unknown"
        
    # Wage month
    month_year_str = find_after(all_text, "Dues for the wage month of", 30)
    m = re.search(r"\d", month_year_str)
    if m:
        first_digit_idx = m.start()
        month_val = month_year_str[:first_digit_idx].strip()
        raw_year_val = 0
        year_m = re.search(r"\d{4}", month_year_str[first_digit_idx:])
        if year_m:
            raw_year_val = int(year_m.group(0))
    else:
        month_val = month_year_str.split(" ")[0] if month_year_str else "Unknown"
        raw_year_val = 0
        
    # FY
    month_upper = month_val.upper()
    is_q1_to_q3 = any(m in month_upper for m in ("APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"))
    fy_start = raw_year_val if is_q1_to_q3 else (raw_year_val - 1 if raw_year_val > 0 else 0)
    financial_year = f"{fy_start}-{str(fy_start+1)[-2:]}" if fy_start > 0 else "Unknown"
    
    # Challan date
    gen_str = find_after(all_text, "system generated challan on ", 20)
    challan_date = gen_str.split(" ")[0] if gen_str else "Unknown"
    
    # Table amounts
    rAdmin = g_pf("Administration Charges")
    rEmployer = g_pf("Employer")
    rEmployee = g_pf("Employee")
    
    employer_epf_ac01 = rEmployer[0]
    employer_eps_ac10 = rEmployer[2]
    employer_edli_ac21 = rEmployer[3]
    pf_admin_ac02 = rAdmin[1]
    edli_admin_ac22 = rAdmin[4]
    employee_epf_ac01 = rEmployee[0]
    
    month_indices = {
        "APR": 1, "MAY": 2, "JUN": 3, "JUL": 4, "AUG": 5, "SEP": 6,
        "OCT": 7, "NOV": 8, "DEC": 9, "JAN": 10, "FEB": 11, "MAR": 12
    }
    mi = month_indices.get(month_upper[:3], 0)
    if mi > 0 and fy_start > 0:
        cal_m = mi + 3 if mi <= 9 else mi - 9
        cal_y = fy_start if mi <= 9 else fy_start + 1
        period_date = pd.Timestamp(year=cal_y, month=cal_m, day=1)
    else:
        period_date = None
        
    return {
        "ReturnType": "PF",
        "EntityID": estab_code,
        "EntityName": estab_name,
        "FY": financial_year,
        "Challan_Date": challan_date,
        "Employer_EPF_AC01": employer_epf_ac01,
        "Employer_EPS_AC10": employer_eps_ac10,
        "Employer_EDLI_AC21": employer_edli_ac21,
        "PF_Admin_AC02": pf_admin_ac02,
        "EDLI_Admin_AC22": edli_admin_ac22,
        "Employee_EPF_AC01": employee_epf_ac01,
        "PeriodDate": period_date,
        "Month": month_val
    }

def parse_esic(pdf, fname) -> dict:
    all_text = get_pdf_combined_text(pdf)
    
    # Period
    period_str_raw = find_after(all_text, "Challan Period:", 20)
    period_str = period_str_raw.split(" ")[0] if period_str_raw else ""
    if "-" in period_str:
        parts = period_str.split("-")
        month_val = parts[0]
        try:
            raw_year_val = int(parts[1])
            if raw_year_val < 100:
                raw_year_val += 2000
        except ValueError:
            raw_year_val = 0
    else:
        month_val = "Unknown"
        raw_year_val = 0
        
    month_upper = month_val.upper()
    is_q1_to_q3 = any(m in month_upper for m in ("APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"))
    fy_start = raw_year_val if is_q1_to_q3 else (raw_year_val - 1 if raw_year_val > 0 else 0)
    financial_year = f"{fy_start}-{str(fy_start+1)[-2:]}" if fy_start > 0 else "Unknown"
    
    # Amount Paid
    amt_str_raw = find_after(all_text, "Amount Paid:", 20)
    amount_paid_val = to_float(amt_str_raw.split(" ")[0]) if amt_str_raw else 0.0
    
    # Challan Number
    challan_num_raw = find_after(all_text, "Challan Number", 30)
    challan_cleaned = challan_num_raw.replace(":", "").strip()
    challan_num = challan_cleaned.split(" ")[0] if challan_cleaned else "Unknown"
    
    # Challan Submitted Date
    date_str_raw = find_after(all_text, "Challan Submitted Date", 30)
    date_str = date_str_raw.split(" ")[0] if date_str_raw else "Unknown"
    
    month_indices = {
        "APR": 1, "MAY": 2, "JUN": 3, "JUL": 4, "AUG": 5, "SEP": 6,
        "OCT": 7, "NOV": 8, "DEC": 9, "JAN": 10, "FEB": 11, "MAR": 12
    }
    mi = month_indices.get(month_upper[:3], 0)
    if mi > 0 and fy_start > 0:
        cal_m = mi + 3 if mi <= 9 else mi - 9
        cal_y = fy_start if mi <= 9 else fy_start + 1
        period_date = pd.Timestamp(year=cal_y, month=cal_m, day=1)
    else:
        period_date = None
        
    return {
        "ReturnType": "ESIC",
        "EntityID": "",
        "EntityName": "",
        "FY": financial_year,
        "Amount": amount_paid_val,
        "ChallanNumber": challan_num,
        "ChallanDate": date_str,
        "PeriodDate": period_date,
        "Month": month_val
    }
